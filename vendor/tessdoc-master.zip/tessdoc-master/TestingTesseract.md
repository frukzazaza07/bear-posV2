This is a place holder for the testing.  (Should at least mention [unit test builds](Compiling-%E2%80%93-GitInstallation.md#unit-test-builds) ...)
