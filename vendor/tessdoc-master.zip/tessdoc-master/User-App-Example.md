Here you can find an example of a simple user application that uses tesseract.

[CMAKE+SW](https://github.com/SoftwareNetwork/sw/tree/master/test/integrations/cmake/tess)

Sw is a package manager for C++.
